
in run_docker_build.sh line 42:
```
DOCKER_RUN_ARGS="-it --dns 8.8.8.8"
```